# SmartTrip 3.0

A frontend-only travel platform prototype built with HTML, CSS and JavaScript.

## Demo highlights
- Login/signup with email OR Indian mobile validation
- Random CAPTCHA on every authentication attempt
- Login required before booking
- Smart Trip Builder using budget, days, travellers and travel interests
- Area-aware hotel demo pricing
- Flight comparison
- Indian bus operator/service demo inventory and visual seat selection
- Cab comparison
- Demo payment and booking confirmation
- Travel wallet / My Trips
- Profile and logout
- Dark mode
- Responsive layout

## Important
This is a frontend prototype. Hotel prices, bus schedules/fares, flight inventory and payment are demo data. A production system should use a backend, secure authentication, server-side CAPTCHA verification, encrypted/session-based auth, and official travel APIs.
