const $=id=>document.getElementById(id);
const storeKey="smarttrip30";
let currentUser=JSON.parse(localStorage.getItem("smarttrip_user")||"null");
let bookings=JSON.parse(localStorage.getItem(storeKey+"_bookings")||"[]");
let itinerary=JSON.parse(localStorage.getItem(storeKey+"_itinerary")||"[]");
let authMode="login", authRole="user", captcha="", pendingAction=null, pendingPayment=null, selectedSeats=[], selectedBus=null;

const hotelData={
 Goa:{areas:{"North Goa":1.18,"South Goa":0.92,"Panaji":1.04},hotels:[
  ["Taj Fort Aguada Resort & Spa, Goa","North Goa",12500,4.7,"Resort"],
  ["Taj Holiday Village Resort & Spa, Goa","North Goa",10900,4.6,"Beach Resort"],
  ["ITC Grand Goa, a Luxury Collection Resort & Spa","South Goa",13800,4.8,"Luxury"]]},
 Mumbai:{areas:{"South Mumbai":1.35,"Bandra":1.22,"Andheri":.92},hotels:[
  ["The Oberoi Mumbai","South Mumbai",14500,4.8,"Luxury"],
  ["The St. Regis Mumbai","Lower Parel",15800,4.7,"Luxury"],
  ["JW Marriott Mumbai Juhu","Andheri",11200,4.6,"City Hotel"]]},
 Hyderabad:{areas:{"Banjara Hills":1.15,"HITEC City":1.22,"Secunderabad":.88},hotels:[
  ["ITC Kohenur, a Luxury Collection Hotel","HITEC City",9800,4.7,"Luxury"],
  ["Hyderabad Marriott Hotel & Convention Centre","Secunderabad",7600,4.6,"City Hotel"],
  ["ITC Kakatiya, a Luxury Collection Hotel","Banjara Hills",8500,4.6,"Luxury"]]},
 Kerala:{areas:{"Kovalam":1.12,"Kochi":1.0,"Bekal":.9},hotels:[
  ["The Leela Kovalam, a Raviz Hotel","Kovalam",10800,4.7,"Beach Resort"],
  ["Kochi Marriott Hotel","Kochi",8200,4.6,"City Hotel"],
  ["Taj Bekal Resort & Spa, Kerala","Bekal",9700,4.8,"Resort"]]},
 Rajasthan:{areas:{"Jaipur City":1.05,"Amer":1.12,"Udaipur":1.2},hotels:[
  ["Taj Amer, Jaipur","Amer",8600,4.7,"Luxury"],
  ["ITC Rajputana, a Luxury Collection Hotel","Jaipur City",9200,4.7,"Luxury"],
  ["The Oberoi Rajvilas, Jaipur","Amer",15500,4.9,"Luxury"]]},
 Araku:{areas:{"Araku Valley":1.0,"Near Borra Caves":.84,"Araku Town":.9},hotels:[
  ["Haritha Valley Resort, Araku","Araku Valley",3200,4.2,"Resort"],
  ["Sunrise Valley Resort","Araku Town",2700,4.1,"Budget"],
  ["Green Valley Stay","Near Borra Caves",2300,4.0,"Budget"]]}
};

const flights=[
 ["IndiGo","6E 218","Vijayawada","Goa","08:25","2h 10m","Non-stop",4820,4.5],
 ["Air India","AI 459","Vijayawada","Goa","11:10","4h 15m","1 stop",5350,4.4],
 ["Air India Express","IX 153","Vijayawada","Goa","14:30","2h 20m","Non-stop",4510,4.3],
 ["Akasa Air","QP 144","Vijayawada","Mumbai","09:20","1h 55m","Non-stop",4290,4.4],
 ["SpiceJet","SG 372","Vijayawada","Delhi","16:40","2h 45m","Non-stop",6100,4.1],
 ["Qatar Airways","QR 529","Hyderabad","Doha","21:20","4h 05m","Non-stop",21400,4.8],
 ["Emirates","EK 525","Hyderabad","Dubai","04:10","4h 00m","Non-stop",23800,4.8],
 ["Vistara","UK 872","Legacy reference","Mumbai","12:00","2h 00m","Non-stop",null,4.6,true],
 ["Deccan Airways","DN 101","Historical reference","Hyderabad","10:00","1h 15m","Non-stop",null,null,true]
];

const buses=[
 ["APSRTC","Indra AC","Vijayawada","Hyderabad","08:00","14:00",680],
 ["APSRTC","Super Luxury","Vijayawada","Hyderabad","09:30","15:30",520],
 ["APSRTC","Amaravathi AC","Vijayawada","Bengaluru","20:30","07:00",1250],
 ["TGSRTC","Rajadhani","Hyderabad","Vijayawada","10:00","16:00",720],
 ["TGSRTC","Garuda","Hyderabad","Vijayawada","11:30","17:30",850],
 ["KSRTC","Airavat Club Class","Bengaluru","Hyderabad","21:00","07:00",1450],
 ["TNSTC","Ultra Deluxe","Chennai","Madurai","07:15","14:00",620]
];

const cabs=[
 ["Uber","Premier","Airport → Hotel",620,4.8],
 ["Ola","Prime Sedan","Airport → Hotel",590,4.6],
 ["Rapido","Cab","Airport → Hotel",420,4.5],
 ["Meru","Sedan","Airport → Hotel",650,4.5]
];

function save(){localStorage.setItem(storeKey+"_bookings",JSON.stringify(bookings));localStorage.setItem(storeKey+"_itinerary",JSON.stringify(itinerary))}
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");clearTimeout(window._toast);window._toast=setTimeout(()=>t.classList.remove("show"),2600)}
function showPage(id){document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));$(id).classList.add("active");scrollTo({top:0,behavior:"smooth"});if(id==="flights")renderFlights();if(id==="hotels")renderHotels();if(id==="buses")searchBuses();if(id==="cabs")renderCabs();if(id==="trips")renderTrips();if(id==="profile")renderProfile();if(id==="admin")renderAdmin()}
function toggleDark(){document.body.classList.toggle("dark");localStorage.setItem("smarttrip_dark",document.body.classList.contains("dark"))}
if(localStorage.getItem("smarttrip_dark")==="true")document.body.classList.add("dark");

function newCaptcha(){captcha=Math.random().toString(36).slice(2,7).toUpperCase();$("captchaText").textContent=captcha}
function setRole(role){authRole=role;$("userRole").classList.toggle("active",role==="user");$("adminRole").classList.toggle("active",role==="admin");$("authRoleHint").textContent=role==="admin"?"Admin login":"User login";$("signupTab").style.display=role==="admin"?"none":"";$("nameWrap").classList.toggle("hidden",role==="admin"||authMode!=="signup");}
function setAuthMode(mode){authMode=mode;$("loginTab").classList.toggle("active",mode==="login");$("signupTab").classList.toggle("active",mode==="signup");$("nameWrap").classList.toggle("hidden",mode!=="signup");$("authTitle").textContent=mode==="login"?"Welcome back 👋":"Create your SmartTrip account";$("authSub").textContent=mode==="login"?"Login to book services and save your trip.":"Create an account to save itineraries, alerts and bookings.";newCaptcha()}
function openAuth(){newCaptcha();$("authModal").classList.remove("hidden")}
function closeAuth(){$("authModal").classList.add("hidden")}
function handleProfile(){if(currentUser){showPage("profile")}else openAuth()}
function submitAuth(){
 const identity=$("authIdentity").value.trim(), pass=$("authPassword").value.trim(), cap=$("captchaInput").value.trim().toUpperCase();
 if(!identity||!pass||!cap)return toast("Please fill all login fields");
 const emailOk=/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(identity), phoneOk=/^[6-9]\d{9}$/.test(identity);
 if(!emailOk&&!phoneOk)return toast("Enter a valid email or 10-digit Indian mobile number");
 if(pass.length<6)return toast("Password must contain at least 6 characters");
 if(cap!==captcha)return toast("Incorrect CAPTCHA. Try again.");
 if(authRole==="admin"){if(identity.toLowerCase()!=="admin@smarttrip.com"||pass!=="Admin@123")return toast("Incorrect admin demo credentials");localStorage.setItem("smarttrip_admin","true");closeAuth();toast("Admin access granted 🛠️");showPage("admin");return;}
 const name=authMode==="signup"?($("authName").value.trim()||"SmartTrip User"):(currentUser?.name||"SmartTrip User");
 currentUser={name,email:emailOk?identity:`${identity.slice(0,3)}******${identity.slice(-2)}`,phone:phoneOk?identity:(currentUser?.phone||""),joined:currentUser?.joined||new Date().toLocaleDateString("en-IN")};
 localStorage.setItem("smarttrip_user",JSON.stringify(currentUser));closeAuth();updateProfile();toast(authMode==="login"?"Login successful 🔐":"Account created 🎉");
 if(pendingAction){const a=pendingAction;pendingAction=null;setTimeout(a,200)}
}
function updateProfile(){const label=$("profileLabel"),av=$("avatar");label.textContent=currentUser?currentUser.name:"Login";av.textContent=currentUser?currentUser.name.split(" ").map(x=>x[0]).slice(0,2).join("").toUpperCase():"👤"}
function logout(){currentUser=null;localStorage.removeItem("smarttrip_user");updateProfile();showPage("home");toast("Logged out successfully")}
function requireLogin(action){if(currentUser)return true;pendingAction=action;openAuth();toast("Login + CAPTCHA required before booking 🔐");return false}

function prefillPlanner(){const d=$("quickDest").value.trim()||"Goa";$("pDest").value=d;$("pBudget").value=$("quickBudget").value;showPage("planner")}
function chooseDestination(d){$("quickDest").value=d;$("pDest").value=d;showPage("planner")}
document.querySelectorAll(".chip").forEach(c=>c.addEventListener("click",()=>c.classList.toggle("selected")));

function buildTrip(){
 const dest=$("pDest").value.trim()||"Goa", days=+$("pDays").value, people=+$("pPeople").value, budget=+$("pBudget").value;
 const vibes=[...document.querySelectorAll(".chip.selected")].map(x=>x.dataset.vibe);
 const baseHotel=hotelData[dest]?.hotels?.[0]?.[2]||4500, areaFactor=hotelData[dest]?.areas?Object.values(hotelData[dest].areas)[0]:1;
 const hotel=Math.round(baseHotel*areaFactor*days*.72), transport=Math.round((dest==="Goa"?4800:dest==="Araku"?2200:4200)*people*.55), food=days*people*650, activities=days*people*450;
 const total=hotel+transport+food+activities, per=Math.round(total/people), score=Math.min(96,72+vibes.length*4+(per<=budget?8:0));
 const activitiesByVibe={nature:"🌿 Scenic viewpoint + nature walk",food:"🍜 Local food trail",adventure:"🥾 Adventure activity",culture:"🏛️ Heritage / museum visit",relax:"🌴 Relaxed evening",photo:"📸 Golden-hour photo stop"};
 let daysHtml="";
 for(let i=1;i<=days;i++){let main=vibes[i%Math.max(vibes.length,1)]||"nature";daysHtml+=`<div class="day"><div class="day-num">DAY ${i}</div><div><h4>${i===1?"Arrival + check-in":i===days?"Highlights + return":"Explore "+dest}</h4><p>🚌 Morning transfer · 🏨 Hotel / stay · ${activitiesByVibe[main]||activitiesByVibe.nature} · 🍴 Local meal · 🚕 Flexible local transport</p></div></div>`}
 $("plannerOutput").innerHTML=`<div class="plan-header"><div><span class="eyebrow">SMART PLAN GENERATED</span><h2>${dest} · ${days} days · ${people} travellers</h2><p class="muted">${vibes.map(v=>"• "+v).join(" ")}</p></div><div class="score">Trip fit ${score}%</div></div>
 <div class="cost-grid"><div class="cost-box"><span>Transport</span><strong>₹${transport.toLocaleString("en-IN")}</strong></div><div class="cost-box"><span>Stay</span><strong>₹${hotel.toLocaleString("en-IN")}</strong></div><div class="cost-box"><span>Food</span><strong>₹${food.toLocaleString("en-IN")}</strong></div><div class="cost-box"><span>Total / person</span><strong>₹${per.toLocaleString("en-IN")}</strong></div></div>
 <div class="pay-summary"><span>Estimated trip total</span><strong>₹${total.toLocaleString("en-IN")}</strong></div><div class="plan-days">${daysHtml}</div>
 <div style="margin-top:18px;display:flex;gap:8px;flex-wrap:wrap"><button class="primary" onclick="addPlanToItinerary('${dest}',${total})">🎫 Save to My Trips</button><button class="secondary" onclick="showPage('hotels')">🏨 Compare hotels</button><button class="secondary" onclick="showPage('buses')">🚌 Compare buses</button></div>`;
}

function addPlanToItinerary(dest,total){if(!requireLogin(()=>addPlanToItinerary(dest,total)))return;itinerary.push({type:"SmartTrip Plan",name:`${dest} ${$("pDays").value}-day plan`,detail:"AI-style itinerary + budget",price:total});save();toast("Trip saved to your travel wallet ✨");showPage("trips")}

function renderFlights(sort="all",btn){
 if(btn){document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));btn.classList.add("active")}
 let arr=[...flights];if(sort==="price")arr.sort((a,b)=>(a[7]??99999)-(b[7]??99999));if(sort==="fast")arr.sort((a,b)=>a[5].localeCompare(b[5]));
 $("flightList").innerHTML=arr.map((x,i)=>`<div class="result-card"><div><div class="provider">${x[0]}</div><div class="muted">${x[1]}</div>${x[9]?'<span class="mini-tag">Legacy / historical reference</span>':''}</div><div><div class="route">${x[2]} → ${x[3]}</div><div class="muted">${x[4]} · ${x[5]} · ${x[6]}</div><div class="result-tags"><span class="mini-tag">🧳 15 kg</span><span class="mini-tag">Standard fare</span></div></div><div><span class="rating">★ ${x[8]||"—"}</span><div class="price">${x[7]?"₹"+x[7].toLocaleString("en-IN"):"—"}<small>${x[9]?"Not bookable":"demo fare + taxes"}</small></div></div><button class="${x[9]?"secondary":"primary"}" onclick="bookFlight(${flights.indexOf(x)})">${x[9]?"Info":"Book"}</button></div>`).join("");
}
function bookFlight(i){const x=flights[i];if(x[9])return toast(`${x[0]} is shown only as a legacy reference.`);startPayment("Flight",`${x[0]} ${x[1]} · ${x[2]} → ${x[3]}`,x[7])}

function updateHotelAreas(){const d=hotelData[$("hotelDestination").value];$("hotelArea").innerHTML=Object.keys(d.areas).map(a=>`<option>${a}</option>`).join("")}
function renderHotels(){updateHotelAreas();const dest=$("hotelDestination").value,area=$("hotelArea").value,d=hotelData[dest],factor=d.areas[area]||1;
 $("hotelList").innerHTML=d.hotels.map((h,i)=>{const areaMatch=h[1]===area, base=h[2], price=Math.round(base*factor*(i===2?.93:1)), old=Math.round(price*1.12);return `<div class="hotel-card"><img src="${["https://images.unsplash.com/photo-1566073771259-6a8506099945","https://images.unsplash.com/photo-1551882547-ff40c63fe5fa","https://images.unsplash.com/photo-1564501049412-61c2a3083791"][i]}" alt="${h[0]}"><div><span class="eyebrow">${h[4]}</span><h3>${h[0]}</h3><div class="muted">📍 ${h[1]} · ${dest} ${areaMatch?"· selected area":""}</div><div class="hotel-meta"><span>★ ${h[3]}</span><span>Pool</span><span>Breakfast</span><span>Free cancellation</span></div><div class="save">SmartTrip area offer · location factor ${factor.toFixed(2)}×</div></div><div class="hotel-price"><div class="old-price">₹${old.toLocaleString("en-IN")}</div><div class="price">₹${price.toLocaleString("en-IN")}<small>per night · demo</small></div><button class="primary" onclick="bookHotel('${h[0].replace(/'/g,"\\'")}',${price})">Book</button></div></div>`}).join("")}
function bookHotel(name,price){if(!requireLogin(()=>bookHotel(name,price)))return;startPayment("Hotel",`${name} · 2 nights`,price*2)}

function searchBuses(){const from=$("busFrom").value.trim(),to=$("busTo").value.trim();$("busList").innerHTML=buses.map((b,i)=>`<div class="bus-card"><div><div class="bus-logo">🚌</div><h3>${b[0]} · ${b[1]}</h3><div class="muted">${b[2]} → ${b[3]}</div></div><div><div class="bus-route">${b[4]} → ${b[5]}</div><div class="muted">AC / operator service · Demo route ${from} → ${to}</div><div class="hotel-meta"><span>2+2 seating</span><span>Live-style seat map</span></div></div><div class="bus-price">₹${b[6].toLocaleString("en-IN")}<small class="muted">per seat · demo</small><button class="primary" onclick="openSeats(${i})">Select seats</button></div></div>`).join("")}
function openSeats(i){selectedBus=buses[i];selectedSeats=[];$("seatTitle").textContent=`${selectedBus[0]} ${selectedBus[1]} · ${selectedBus[2]} → ${selectedBus[3]}`;const booked=new Set([2,5,8,11,14]);$("seatGrid").innerHTML=Array.from({length:20},(_,n)=>`<button class="seat ${booked.has(n)?"booked":""}" ${booked.has(n)?"disabled":""} onclick="toggleSeat(${n},this)">${String.fromCharCode(65+Math.floor(n/4))}${n%4+1}</button>`).join("");updateSeatTotal();$("seatModal").classList.remove("hidden")}
function toggleSeat(n,el){if(el.disabled)return;const idx=selectedSeats.indexOf(n);if(idx>=0){selectedSeats.splice(idx,1);el.classList.remove("selected")}else{selectedSeats.push(n);el.classList.add("selected")}updateSeatTotal()}
function updateSeatTotal(){$("seatCount").textContent=`${selectedSeats.length} seat${selectedSeats.length===1?"":"s"}`;$("seatAmount").textContent="₹"+((selectedBus?.[6]||0)*selectedSeats.length).toLocaleString("en-IN")}
function closeSeats(){$("seatModal").classList.add("hidden")}
function continueBusBooking(){if(!selectedSeats.length)return toast("Select at least one seat");if(!requireLogin(()=>continueBusBooking()))return;const total=selectedBus[6]*selectedSeats.length;closeSeats();startPayment("Bus",`${selectedBus[0]} ${selectedBus[1]} · Seats ${selectedSeats.map(n=>String.fromCharCode(65+Math.floor(n/4))+(n%4+1)).join(", ")}`,total)}

function renderCabs(){$("cabList").innerHTML=cabs.map((c,i)=>`<div class="result-card"><div><div class="provider">${c[0]}</div><div class="muted">${c[1]}</div></div><div><div class="route">${c[2]}</div><div class="muted">ETA 20–35 min · demo estimate</div></div><div><span class="rating">★ ${c[4]}</span><div class="price">₹${c[3]}<small>estimated</small></div></div><button class="primary" onclick="bookCab(${i})">Book</button></div>`).join("")}
function bookCab(i){if(!requireLogin(()=>bookCab(i)))return;startPayment("Cab",`${cabs[i][0]} ${cabs[i][1]}`,cabs[i][3])}

function startPayment(type,summary,amount){pendingPayment={type,summary,amount};$("paymentTitle").textContent=`Book ${type}`;$("paymentSummary").textContent=summary;$("paymentAmount").textContent="₹"+amount.toLocaleString("en-IN");$("paymentModal").classList.remove("hidden")}
function closePayment(){$("paymentModal").classList.add("hidden")}
function completePayment(){if(!$("cardName").value.trim()||$("cardNumber").value.replace(/\s/g,"").length<12)return toast("Enter demo card details");const id="ST"+Math.floor(100000+Math.random()*900000);bookings.unshift({id,...pendingPayment,date:new Date().toLocaleString("en-IN")});itinerary.push({type:pendingPayment.type,name:pendingPayment.summary,detail:"Confirmed booking · "+id,price:pendingPayment.amount});save();closePayment();pendingPayment=null;toast(`Booking confirmed 🎉 ${id}`);showPage("trips")}

function renderTrips(){
 if(!currentUser){$("tripDashboard").innerHTML=`<div class="dashboard-card"><h3>Login to open your travel wallet</h3><p class="muted">Your bookings and saved plans stay behind the login + CAPTCHA gate.</p><button class="primary" onclick="openAuth()">Login</button></div>`;return}
 const bookingHtml=bookings.length?`<div class="booking-grid">${bookings.map(b=>`<div class="booking-item"><small>${b.type}</small><b>${b.summary}</b><small>${b.id}</small><strong>₹${b.amount.toLocaleString("en-IN")}</strong></div>`).join("")}</div>`:"<p class='muted'>No confirmed bookings yet.</p>";
 const itemHtml=itinerary.length?`<div class="booking-grid">${itinerary.map(x=>`<div class="booking-item"><small>${x.type}</small><b>${x.name}</b><small>${x.detail}</small><strong>₹${x.price.toLocaleString("en-IN")}</strong></div>`).join("")}</div>`:"<p class='muted'>Your saved itinerary is empty.</p>";
 $("tripDashboard").innerHTML=`<div class="dashboard-card"><span class="eyebrow">CONFIRMED BOOKINGS</span><h3>Travel wallet</h3>${bookingHtml}</div><div class="dashboard-card"><span class="eyebrow">SAVED PLANS</span><h3>My itinerary</h3>${itemHtml}</div><div class="dashboard-card emergency"><span class="eyebrow">EMERGENCY TRIP CARD</span><h3>🚨 Quick access</h3><div class="booking-grid"><div class="booking-item"><small>Traveller</small><b>${currentUser.name}</b></div><div class="booking-item"><small>Contact</small><b>${currentUser.phone||currentUser.email}</b></div><div class="booking-item"><small>Booking count</small><b>${bookings.length}</b></div></div></div>`
}
function renderProfile(){if(!currentUser){$("profileBox").innerHTML=`<div class="dashboard-card"><h3>Not logged in</h3><button class="primary" onclick="openAuth()">Login</button></div>`;return}const initials=currentUser.name.split(" ").map(x=>x[0]).slice(0,2).join("").toUpperCase();$("profileBox").innerHTML=`<div class="profile-card"><div class="profile-avatar">${initials}</div><div class="grow"><h2>${currentUser.name}</h2><p class="muted">${currentUser.email}</p><small class="muted">Member since ${currentUser.joined}</small></div><button class="primary" onclick="logout()">Logout</button></div><div class="profile-details"><div class="profile-field"><small>Phone</small><b>${currentUser.phone||"Not added"}</b></div><div class="profile-field"><small>Bookings</small><b>${bookings.length}</b></div><div class="profile-field"><small>Saved items</small><b>${itinerary.length}</b></div></div>`}


function handleAdmin(){if(localStorage.getItem("smarttrip_admin")==="true")showPage("admin");else{setRole("admin");setAuthMode("login");openAuth()}}
function logoutAdmin(){localStorage.removeItem("smarttrip_admin");showPage("home");toast("Admin logged out")}
function refreshAdmin(){renderAdmin();toast("Dashboard refreshed")}
function renderAdmin(){
 const users=currentUser?[currentUser]:[], total=bookings.reduce((s,b)=>s+(b.amount||0),0);
 $("adminStats").innerHTML=[["👥","Users",users.length],["🎫","Bookings",bookings.length],["💰","Booking value","₹"+total.toLocaleString("en-IN")],["🏨","Hotels",Object.values(hotelData).reduce((s,d)=>s+d.hotels.length,0)],["✈️","Flights",flights.filter(x=>!x[9]).length],["🚌","Bus services",buses.length]].map(x=>`<div class="admin-stat"><div>${x[0]}</div><small>${x[1]}</small><strong>${x[2]}</strong></div>`).join("");
 const vals=[1,2,3,2,4,Math.max(2,bookings.length+2)], max=Math.max(...vals), mons=["Apr","May","Jun","Jul","Aug","Sep"];
 $("adminChart").innerHTML=vals.map((v,i)=>`<div class="bar-col"><b>${v}</b><div class="bar" style="height:${Math.max(10,v/max*175)}px"></div><span>${mons[i]}</span></div>`).join("");
 const counts={};bookings.forEach(b=>{const m=(b.summary||"").match(/→\s*([^·]+)/);const d=m?m[1].trim():"Other";counts[d]=(counts[d]||0)+1});const top=Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,5);
 $("adminDestinations").innerHTML=(top.length?top:[["Goa",0],["Hyderabad",0],["Kerala",0]]).map((x,i)=>`<div class="rank-row"><div class="rank-num">${i+1}</div><div><b>${x[0]}</b><small>Booking activity</small></div><strong>${x[1]}</strong></div>`).join("");
 $("adminBookings").innerHTML=bookings.length?bookings.slice(0,6).map(b=>`<div class="admin-booking"><div class="rank-num">${(b.type||"B")[0]}</div><div><b>${b.summary}</b><small>${b.id} · ${b.date}</small></div><strong>₹${b.amount.toLocaleString("en-IN")}</strong></div>`).join(""):"<p class='muted'>No bookings yet. Make a demo booking to populate this panel.</p>";
 $("adminUsers").innerHTML=users.length?users.map(u=>`<div class="admin-user"><div class="rank-num">👤</div><div><b>${u.name}</b><small>${u.email}</small></div><strong>Active</strong></div>`).join(""):"<p class='muted'>No users created in this browser yet.</p>";
}
function adminAction(x){toast(x+" management opened. Connect this control to your backend in production.")}
function adminNotify(){toast("Notification composer ready 🔔")}
function adminOffer(){toast("Demo hotel offer created: Smart Saver 15%")}
function adminExport(){const r={generated:new Date().toISOString(),users:currentUser?[currentUser]:[],bookings,inventory:{hotels:Object.values(hotelData).reduce((s,d)=>s+d.hotels.length,0),flights:flights.length,buses:buses.length,cabs:cabs.length}};const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(r,null,2)],{type:"application/json"}));a.download="smarttrip-admin-report.json";a.click();toast("Admin report exported")}

document.addEventListener("DOMContentLoaded",()=>{
 updateProfile();newCaptcha();renderFlights();renderHotels();searchBuses();renderCabs();$("busDate").value=new Date().toISOString().slice(0,10);
});
window.addEventListener("click",e=>{if(e.target.classList.contains("modal"))e.target.classList.add("hidden")});
