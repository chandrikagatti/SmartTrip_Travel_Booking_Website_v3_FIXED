# SmartTrip v3

Enhanced student-project travel booking platform.

## Added in v3
- 10 Indian states explorer:
  Goa, Kerala, Rajasthan, Maharashtra, Karnataka, Telangana, Tamil Nadu, Himachal Pradesh, Uttarakhand, Andhra Pradesh.
- Clicking a state opens a dedicated destination page with:
  - Real hotel/property names
  - Hotel descriptions and photos
  - Nearby tourist places
  - Hotel/local transport options
  - Cab comparison shortcut
- More flight options using real airline names.
- Current-airline accuracy:
  - Vistara is not listed as a current standalone carrier because it merged into Air India on 12 Nov 2024.
  - A Vistara-era Air India flight code is shown as AI 2955 for demonstration.
  - Deccan Airways is shown only as a historical/legacy reference and is not bookable.
- More real hotel names from official hotel brand/property listings.
- Real cab brand names in the demo: Uber, Ola, Rapido, Meru.
- Login/signup is now required before any service can be booked.
- After login, the profile button shows the account name.
- Profile page displays name, email, member date, booking count and itinerary count.
- Logout is available from the profile page.
- After logout, clicking Book opens login and the service cannot be booked until the user logs in again.
- LocalStorage persists demo account, trips and itinerary.
- Existing dark mode, responsive mobile UI, itinerary builder, alerts, payment page and fare breakdown remain.

## Data note
Property names and destination highlights are based on public information from official hotel websites and India tourism resources. Prices, ratings, availability and schedules displayed in this demo are illustrative unless explicitly marked otherwise.

## Run
Open `index.html` in VS Code and use Live Server.
